<?php

namespace App\Http\Controllers;

use App\Models\Job;
use Illuminate\Http\Request;

class JobApplicationController extends Controller
{
    public function store(Request $request)
    {




        $contact = new Job();
        $contact->name = $request->name;
        $contact->subject = $request->mobile;
        $contact->email = $request->email;
        $contact->message = $request->experience;
        $contact->message = $request->qualification;
        $contact->message = $request->resume;
        $contact->save();


        return redirect()->back()->with('success', 'We will Connect As Soon!');
}

}
